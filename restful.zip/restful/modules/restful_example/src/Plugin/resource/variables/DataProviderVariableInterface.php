<?php

/**
 * @file
 * Contains \Drupal\restful_example\Plugin\resource\variables\DataProviderVariableInterface.
 */

namespace Drupal\restful_example\Plugin\resource\variables;

use Drupal\restful\Plugin\resource\DataProvider\DataProviderInterface;

interface DataProviderVariableInterface extends DataProviderInterface {}
