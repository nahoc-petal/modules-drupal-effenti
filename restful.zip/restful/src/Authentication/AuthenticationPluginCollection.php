<?php

/**
 * @file
 * Contains \Drupal\restful\Authentication\AuthenticationPluginCollection
 */

namespace Drupal\restful\Authentication;

use Drupal\Core\Plugin\DefaultLazyPluginCollection;

class AuthenticationPluginCollection extends DefaultLazyPluginCollection {}
