<?php

/**
 * @file
 * Contains \Drupal\restful\Plugin\resource\DataInterpreter\DataInterpreterArray.
 */

namespace Drupal\restful\Plugin\resource\DataInterpreter;

class DataInterpreterArray extends DataInterpreterBase implements DataInterpreterInterface {}
